#include <xc.h>

void T0delay(void);
void Display(unsigned char);
