#include <xc.h>
#include<stdlib.h>
// Pragma Configuration
#pragma config OSC = XT         // Oscillator Selection bits (HS oscillator)
#pragma config WDT = OFF        // Watchdog Timer Enable bit (WDT disabled (control is placed on the SWDTEN bit))
#pragma config LVP = OFF        // Single-Supply ICSP Enable bit (Single-Supply ICSP disabled)
// Include Libraries

// Variable Definations
#define _XTAL_FREQ 4000000
#define TMR2PRESCALE 4
#define OP PORTBbits.RB1
#define SW1 PORTAbits.RA4
#define SW2 PORTAbits.RA5
#define RS PORTEbits.RE0
#define EN PORTEbits.RE1
#define C4 PORTCbits.RC4
#define C5 PORTCbits.RC5
#define C6 PORTCbits.RC6
#define C7 PORTCbits.RC7
#define OP1 PORTBbits.RB7

// Functions Declaration 

// Timer
void Timer0(void);

// Seven Segment Display
void Display(unsigned char);

// ADC for Water Flow Rate
void ADC_Init(void);
void ADC_Conversion(void);

// LCD Display Functions
void Lcd_Start(void);
void Lcd_SetBit(char data_bit);
void Lcd_Cmd(char a);
void Lcd_Clear(void);
void Lcd_Set_Cursor(char a, char b);
void Lcd_Print_Char(char data);
void Lcd_Print_String(char *a);
void Print_num(int adc_value1);
unsigned int get_count(void);
int power(int, int);    

// Bulb Brightness Control
void PWM_Initialize(void);
void PWM_Duty(unsigned int duty);

// External Interrupt for Power Management
void Interrupt_init(void);
void INT0_ISR(void);
void chk_ISR(void);

// Interrupts Priority Functions
void __interrupt(low_priority) ISRL(void);
void __interrupt(high_priority) chk_ISR(void);


// Variable and Array Initialization and Declaration
unsigned int value, i, x, f, count, adc_value;
int temp, counter;
int arr_dec[17]  ={0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15}; // DECIMAL ARRAY
int arr_hex[3] = {}; // ARRAY TO HOLD INDIVIDUAL HEX VALUE
char decimal_data[3] = {}; // ARRAY TO STORE INDIVIDUAL DECIMAL VALUE
unsigned char units, tens;
unsigned char seg[]={0x40,0x79,0x24,0x30,0x19,0x12,0x02,0x78,0x00,0x10}; 
long PWM_freq = 5000;

// Main Program 
void main()
{ 
    counter  = 25;
    f = 1;

    TRISAbits.TRISA0 = 1;
    TRISAbits.TRISA2 = 1;
    TRISAbits.TRISA3 = 1;
    TRISAbits.TRISA4 = 0;
    TRISAbits.TRISA5 = 0;
    
    TRISBbits.TRISB0 = 1;
    TRISBbits.TRISB1 = 0;
    
    TRISEbits.TRISE0 = 0;
    TRISEbits.TRISE1 = 0;

    TRISC = 0;
    TRISD = 0;
    
// Initialize Functions
    Lcd_Start();
    ADC_Init();
    PWM_Initialize();
    Interrupt_init();
    Timer0();
    
    Lcd_Clear();
    Lcd_Set_Cursor(1,1);
    Lcd_Print_String("Flow Rate: ");

// Infinite loop        
    while(1)
    {
        ADC_Conversion();
        Lcd_Set_Cursor(1,12);
        PWM_Duty(adc_value);
        Print_num(adc_value);
        
        Lcd_Set_Cursor(2,1);
        Lcd_Print_String("Water Temp: ");
        Lcd_Set_Cursor(2,13);
        Print_num(counter);
                        

        if(PORTAbits.RA2)
        {
            __delay_ms(100);
            if(PORTAbits.RA2)
            {
                counter = counter+1;
                Lcd_Set_Cursor(2,13);
                Print_num(counter);
            }        
        }
        if(PORTAbits.RA3)
        {
            __delay_ms(100);
            if(PORTAbits.RA3)
            {
                counter = counter-1;
                Lcd_Set_Cursor(2,13);
                Print_num(counter);
            }       
        }      
    }
}

// Functions 
void chk_ISR()
{
    if(INTCONbits.INT0IF==1)
    {
        INT0_ISR();
    }
}

void INT0_ISR()
{
    
    if(f==1)
    {
        Display(1);
        OP1 = 1;
        f++;
    }
    else if(f==2)
    {
        Display(0);
        OP1 = 0;
        f--;
    }
    INTCONbits.INT0IF=0;
}
void Interrupt_init(void)
{
    TRISBbits.TRISB0=1;
    TRISBbits.TRISB7=0;
    RCONbits.IPEN    = 0; 
    INTCONbits.INT0IF= 0;
    INTCONbits.GIE   = 1;
    INTCONbits.PEIE  = 1;
    INTCONbits.INT0IE= 1;
    INTCON2bits.INTEDG0=1;
    Display(0);
}
void Print_num(int adc_value1)
{
    for(int i=0; i<3; i++)
        {
            arr_hex[i] = (adc_value1%16);    //SEPERATE INDIVIDUAL HEX BITS 
            temp = arr_hex[i];
            adc_value1 /= 16;
            decimal_data[i] = arr_dec[temp]; // COMPARE HEX BITS WITH DECIMAL BIT ARRAY
                                       // TO STORE DECIMAL VALUES IN DECIMAL_DATA 
        }

          count = get_count();      //FUNCTION TO CONVERT HEXADECIMAL VALUE TO DECIMAL   
        
          Lcd_Print_Char((count/1000)+48); // SEPERATE BITS AND PRINT
          count = count%1000;     
          Lcd_Print_Char((count/100)+48);
          count = count%100;
          Lcd_Print_Char((count/10)+48);
          count = count%10;
          Lcd_Print_Char((count)+48);     
}
void ADC_Init()
{
    ADCON0=0x01;         //AN0 Channel, A/D is On, Conversion not Started
    ADCON1=0x0E;         //Vdd & Vss as refrence voltages, AN0 as analog and Other as I/O
    ADCON2=0xAE;         // Right Justified, 12 Tad Acquisition Time, Fosc/64 Conversion Clock
}
void ADC_Conversion()
{
    __delay_ms(5);
    ADCON0bits.GO=1;
    while(ADCON0bits.DONE==1);
    __delay_ms(5);
    adc_value = ((ADRESH<<8)+(ADRESL));        
}
void __interrupt(low_priority) ISRL()
{
    if(TMR0IF && TMR0IE)
    {
        OP = ~OP;
        TMR0H = 48;
        TMR0L = 229;
        INTCONbits.TMR0IF = 0;
    }
    return;
}
void Timer0()
{  
    INTCONbits.GIE = 0;
    RCONbits.IPEN = 1;
    INTCON2bits.TMR0IP = 0;
    TMR0H=48;
    TMR0L=229;
    T0CON=0b10000101;
    INTCON = 0b11110000;
}
void Display(unsigned char n)
{
    tens =  n/10; // Separate tens from a two digit number
    units = n%10; // Separate units from a two digit number 
    {
    SW1 = 1;     // Select one display to show units value
    SW2 = 0; 
    PORTD = seg[units]; // Display units
    __delay_ms(5);
    }
}

void Lcd_SetBit(char data_bit) //Based on the Hex value Set the Bits of the Data Lines
{
    if(data_bit& 1) 
        C4 = 1;
    else
        C4 = 0;

    if(data_bit& 2)
        C5 = 1;
    else
        C5 = 0;

    if(data_bit& 4)
        C6 = 1;
    else
        C6 = 0;

    if(data_bit& 8) 
        C7 = 1;
    else
        C7 = 0;
}

void Lcd_Cmd(char a)
{
    RS = 0;           
    Lcd_SetBit(a); //Incoming Hex value
    EN  = 1;         
        __delay_ms(4);
        EN  = 0;         
}

void Lcd_Clear()
{
    Lcd_Cmd(0); //Clear the LCD
    Lcd_Cmd(1); //Move the curser to first position
}

void Lcd_Set_Cursor(char a, char b)
{
    char temp,z,y;
    if(a== 1)
    {
      temp = 0x80 + b - 1; //80H is used to move the curser
        z = temp>>4; //Lower 8-bits
        y = temp & 0x0F; //Upper 8-bits
        Lcd_Cmd(z); //Set Row
        Lcd_Cmd(y); //Set Column
    }
    else if(a== 2)
    {
        temp = 0xC0 + b - 1;
        z = temp>>4; //Lower 8-bits
        y = temp & 0x0F; //Upper 8-bits
        Lcd_Cmd(z); //Set Row
        Lcd_Cmd(y); //Set Column
    }
}

void Lcd_Start()
{
  Lcd_SetBit(0x00);
  for(int i=100; i<=0; i--)  NOP();  
  Lcd_Cmd(0x03);
    __delay_ms(5);
  Lcd_Cmd(0x03);
    __delay_ms(11);
  Lcd_Cmd(0x03); 
  Lcd_Cmd(0x02); //02H is used for Return home -> Clears the RAM and initializes the LCD
  Lcd_Cmd(0x02); //02H is used for Return home -> Clears the RAM and initializes the LCD
  Lcd_Cmd(0x08); //Select Row 1
  Lcd_Cmd(0x00); //Clear Row 1 Display
  Lcd_Cmd(0x0C); //Select Row 2
  Lcd_Cmd(0x00); //Clear Row 2 Display
  Lcd_Cmd(0x06);
}

void Lcd_Print_Char(char data)  //Send 8-bits through 4-bit mode
{
   char Lower_Nibble,Upper_Nibble;
   Lower_Nibble = data&0x0F;
   Upper_Nibble = data&0xF0;
   RS = 1;             // => RS = 1
   Lcd_SetBit(Upper_Nibble>>4);             //Send upper half by shifting by 4
   EN = 1;
   for(int i=100; i<=0; i--)  NOP(); 
   EN = 0;
   Lcd_SetBit(Lower_Nibble); //Send Lower half
   EN = 1;
   for(int i=100; i<=0; i--)  NOP();
   EN = 0;
}

void Lcd_Print_String(char *a)
{
    int i;
    for(i=0;a[i]!='\0';i++)
       Lcd_Print_Char(a[i]);  //Split the string using pointers and call the Char function 
}
unsigned int get_count(void)  // FUNCTION TO CONVERT HEX NUMBER IN DECIMAL
{
    int i;
    unsigned int count=0;
    for(i=2; i>=0; i--)
    {
        count += (decimal_data[i]*power(16,i));  // FORMULA FOR CONVERSION
    }
    
    return count;
}

int power(int x, int y)  // FUNCTION TO CALCULATE POWER
{
    unsigned int result = 1;
    while(y!=0)
    {
        result = result*x;
        y--;
    }
    return result;
}
void PWM_Initialize()
{
  PR2 = (_XTAL_FREQ/(PWM_freq*4*TMR2PRESCALE)) - 1; //Setting the PR2 formulae using Datasheet // Makes the PWM work in 5KHZ
    CCP1M3 = 1; CCP1M2 = 1;  //Configure the CCP1 module 
    T2CKPS0 = 1;T2CKPS1 = 0; TMR2ON = 1; //Configure the Timer module
    TRISC2 = 0; // make port pin on C as output
}
void PWM_Duty(unsigned int duty)
{
      if(duty<1023)
  {
    duty = ((float)duty/1023)*(_XTAL_FREQ/(PWM_freq*TMR2PRESCALE)); // On reducing //duty = (((float)duty/1023)*(1/PWM_freq)) / ((1/_XTAL_FREQ) * TMR2PRESCALE);
    CCP1X = duty & 1; //Store the 1st bit
    CCP1Y = duty & 2; //Store the 0th bit
    CCPR1L = duty>>2;// Store the remining 8 bit
  }
}
