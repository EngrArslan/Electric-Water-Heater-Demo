/*
 * File:   functions.c
 * Author: Mustafa Imran
 *
 * Created on January 11, 2021, 12:07 AM
 */


#include <xc.h>
#include"header.h"
#include"newmain.c"
void T0delay()
{
    T0CON=0x05;
    TMR0H=0xC3;
    TMR0L=0x50;
    T0CONbits.TMR0ON=1;
    while(INTCONbits.TMR0IF==0);
    T0CONbits.TMR0ON=0;
    INTCONbits.TMR0IF=0;
}
void Display(unsigned char n)
{
tens =  n/10; // Separate tens from a two digit number
units = n%10; // Separate units from a two digit number
for(x = 0; x<10; x++) 
{
SW1 = 1;     // Select one display to show units value
SW2 = 0; 
PORTD = seg[units]; // Display units
__delay_ms(5);
//T0delay();
SW1 = 0;
SW2 = 1; // Select second display to show tens value
PORTD = seg[tens]; // Display tens
__delay_ms(5);
//T0delay();
}
}

